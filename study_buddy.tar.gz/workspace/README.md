Study M8 by Team Queso

This project comes in two parts:
    1. The Website
    2. The Google Chrome Extension

The Website:
    1. This website is run on Cloud 9 - If you wish to run it you must first log in to Cloud 9
    2. To have access to this website, please contact a contributor.
    
    
The Google Chrome Extension:
    - Please download the "localHackExt" folder (you may need to unzip it)
    
    Load it:
      - In Google Chrome type the following url: chrome://extensions/
      - Next, check "Developer mode"
      - Click: "Load unpacked extension".
      - Navigate to the "localHackExt" folder and upload it
      - Ensure that the enabled checkbox is checked
  
Fill out the: url, userid, tag, comment, and press submit, then check back to the website.